

})(jQuery, window.freebase.controls);