<?php
	drupal_get_form('fivestar_average_form');
        drupal_add_js("sites/all/modules/film_search/includes/jquery-latest.js");
	drupal_add_css("sites/all/modules/film_search/includes/css/jquery.freebase.minitopic.css");
	drupal_add_js("sites/all/modules/film_search/includes/jquery.freebase.minitopic.js");
	drupal_add_js("sites/all/modules/film_search/includes/ajax.js");

?>
