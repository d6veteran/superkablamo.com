<?php
echo "Testing search module";
?>
