$(document).ready(function(){$('#miniTopic').show().freebaseMiniTopic(dynamicid);});
